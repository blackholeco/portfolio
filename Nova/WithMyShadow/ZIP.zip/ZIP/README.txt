﻿###################
With My Shadow (working title)
###################

Copyright (C) Chris Allen 2019.  All rights reserved.

This project is provided AS-IS, for demonstration purposes only.  The project, as a whole or in part, is not intended for use beyond demonstration purposes.  You may not use this project, or its contents, for any use beyond its stated intention.

You may not claim this work, or the related files, as your own work.  You may not reverse-engineer, alter, or make copies of the project, or its contents.  You may not redistribute this project, or its contents.

An installer is provided to install all required files to your system.  Those files are protected by this copyright/license.

If you have any issues with installing or running the project, please let me know, and I will try to support you as best as possible.

PLEASE NOTE:
"With My Shadow" is the working title of the project, and may not be the final name.  This project is not to be confused or associated with existing works of a similar name.
Content, such as graphics and audio, as well as gameplay modes, are subject to change.

###################
Requirements
###################
You will need to run this project on a Windows PC, 7 or later (may work on Vista, but hasn't been tested)

OpenGL 4.0 or above is required.

The Visual C++ runtime should be installed by the installer, as it is required for the project to run.

###################
Application Configuration
###################
If you have any problems running the application, try altering the config.txt file.  Currently, there are two options in there:
-fullscreen: Opens the app in fullscreen mode
-adaptive_vsync: Manages vsync, enabling it at high FPS< and disabling it at low FPS.  This should help maintain a smooth experience.
Adaptive VSync is not supported by every system, and this setting will be ignored if you cannot support it.

To disable the above settings, add a hash symbol (#) at the start of the line to comment it out.  You can turn it back on again by
deleting the hash symbol.

###################
How To Play
###################
With My Shadow is a side-scroller, where you control two characters on separate tracks.  The characters are the player (upper track), and their Shadow counterpart (lower track).

Obstacles will randomly appear, blocking your path.  Avoid these to keep going.

The Character and the Shadow move independantly of each other.  The action of one is not mirrored by the other.

The level will speed up the further you travel.

You have a limited amount of health, which decreases as you collide with obstacles.  If your health drops to 0, the game ends.

The further you travel, the higher your score will be.  High scores will be entered onto a local leaderboard.

###################
Controls
###################
The player character will take the best action based on the next obstacle on the track.  Press the character's action button to have them respond.

W: Normal/upper track's action button
S: Shadow/lower track's action button.

Press Escape at any time to close the program.

###################
Credits
###################
This project uses work by third party authors.  They are credited below.

Resources & Assets
###################

FONT:
	The 'Montserrat' Font, Copyright (c) 2011-2012, Julieta Ulanovsky (julieta.ulanovsky@gmail.com), with Reserved Font Names 'Montserrat'.  This Font Software is licensed under the SIL Open Font License, Version 1.1. (Available from http://scripts.sil.org/OFL)

	The Montserrat Font is available from Google Fonts (https://fonts.google.com/specimen/Montserrat?selection.family=Montserrat)

GRAPHICS:
	"Forest01".  Available from GameDevMarket.  Created by MGG.  Part of the "Pixelart Game Backgrounds" Package.

	"player".  Part of the PlatformerPack for Spriter.  Art and Animation created by Michael Parent (www.brashmonkey.com)

MUSIC:
	"Catch the Mystery".  Available from GameDevMarket.  Created by Snabisch.  Part of the "Music Loops for 8bit Games" Package.

SOUNDS: 
	"Retro_8-Bit_Game-Bomb_Explosion_10".  Available from GameDevMarket.  Created by fusehive.  Part of the "8-Bit Retro Game SFX" Package.

	"Retro_8-Bit_Game-Jump_Lift_TakeOff_06".  Available from GameDevMarket.  Created by fusehive.  Part of the "8-Bit Retro Game SFX" Package.

	"Damage04".  Available from GameDevMarket.  Created by CactusBear.  Part of the "8-Bit SFX Pack" Package.


3rd party libraries:
###################

THE FREETYPE LIBRARY (available under the FreeType License (FTL)):


	Portions of this software are copyright © 1996-2019 The FreeType Project (www.freetype.org).  All rights reserved.

	The FreeType library is available from https://www.freetype.org/


THE OPENGL EXTENSION WRANGLER LIBRARY (GLEW) (Available under the Modified BSD License):

	Copyright (C) 2008-2016, Nigel Stewart <nigels[]users sourceforge net>
	Copyright (C) 2002-2008, Milan Ikits <milan ikits[]ieee org>
	Copyright (C) 2002-2008, Marcelo E. Magallon <mmagallo[]debian org>
	Copyright (C) 2002, Lev Povalahev
	All rights reserved.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
	IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
	ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
	LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
	CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
	SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
	INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
	CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
	ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
	THE POSSIBILITY OF SUCH DAMAGE.

	The GLEW library is available from http://glew.sourceforge.net/


THE GLFW LIBRARY (Available under the zlib/libpng license):

	Copyright © 2002-2006 Marcus Geelnard
	Copyright © 2006-2019 Camilla Löwy

	The GLFW library is available from https://www.glfw.org/


THE SIMPLE DIRECTMEDIA LIBRARY (SDL) (Available under the zlib license)
	Copyright (C) 1997-2018 Sam Lantinga <slouken@libsdl.org>

	SDL is available from https://www.libsdl.org/index.php


THE SDL_MIXER LIBRARY (Available under the zlib license)
	Copyright (C) 1997-2018 Sam Lantinga <slouken@libsdl.org>

	The SDL_mixer Library is available from https://www.libsdl.org/projects/SDL_mixer/


THE ZLIB LIBRARY (Available under the zlib license):
	Copyright (C) 1995-2017 Jean-loup Gailly and Mark Adler

	zlib is available from https://zlib.net
