Wind Simulation - Nova Tech Demo

This project serves as a tech demo for the Nova Game Engine.

Copyright 2018 by Chris Allen, all rights reserved.


*** USAGE ***
Simply run WindSim.exe, and the program will run.


This project, and its files, are provided as-is, and are provided for the purposes of forming part of my portfolio.

It is intended to be viewed by potential employers, or interested parties, and for no other use.

You MAY NOT use this work for any other purpose.  You MAY NOT use this work as your own, or edit/alter the files,
partially or wholly, provided for any reason.  You may not make any copies of this project, or its files, for
purposes other than its original intention.  No support will be provided for using this project, or its files,
for any purpose other than its original intention.

This work uses libraries and resources created by third parties, who are credited at the bottom of this file.


*** SYSTEM REQUIREMENTS ***
Windows PC (tested on 7 and 10)
Keyboard
OpenGL 4.0 or above

*** CONTROLS ***
'A'/'D' (held down) : Changes the wind direction, moving it clockwise or anti-clockwise
'W'/'S' : Increase/Decrease wind power


For more information about this project, please see my website, blackholeco.wixsite.com


*** CREDITS ***

Wind Simulation uses the following third party resources:


The 'Montserrat' Font, Copyright (c) 2011-2012, Julieta Ulanovsky (julieta.ulanovsky@gmail.com), with Reserved Font Names 'Montserrat'.  This Font Software is licensed under the SIL Open Font License, Version 1.1. (Available from http://scripts.sil.org/OFL)

The GLFW library, available under the zlib/libpng license (GLFW can be found at www.glfw.org, license available from http://www.opensource.org/licenses/zlib-license.php)

The GLEW library, available from glew.sourceforge.net

The Freetype library, available from www.freetype,org, under the FreeType License (available at http://git.savannah.gnu.org/cgit/freetype/freetype2.git/tree/docs/FTL.TXT)


